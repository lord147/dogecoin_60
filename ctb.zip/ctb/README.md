# Clickbot Tools By Rayez Id

Join to the bot using this link first

>- `DOGE` https://t.me/Dogecoin_click_bot?start=WLKJ

>- `LTC` https://t.me/Litecoin_click_bot?start=jJgZ

>- `BCH` https://t.me/BCH_clickbot?start=kfWg

>- `BTC` https://t.me/BitcoinClick_bot?start=ze55

>- `BCH` https://t.me/BCH_clickbot?start=kfWg



Then copy this command `git clone https://github.com/anarki-install/Clickbot-Tools-Baby/` 


and paste it to your termux, wait until the file being installed on your phone


and then open file by `cd Clickbot-Tools-Baby/files` and the last, run it by execute `python bot.py`


--------------
# ©rayez_id 2020

